package app.entity;

import org.hibernate.validator.constraints.br.CPF;

//import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Aluno {
	
	@Id // para dizer que é uma chave primaria no banco de dados
	@GeneratedValue(strategy = GenerationType.IDENTITY) // para dizer que é um auto incremente no banco de dados 
	private long idAluno;
	
	@Pattern (regexp = "\\S+\\s+\\S+.*$", message = "O nome deve conter duas palavras")
	private String nomeAluno;
	
	@CPF (message = "O CPF deve ser válido")
	private String cpfAluno;
	private String telefoneAluno;
	
	//Vários(um?) alunos podem estar em uma turma
	//@ManyToOne
	//private Turma turma; 
	
}