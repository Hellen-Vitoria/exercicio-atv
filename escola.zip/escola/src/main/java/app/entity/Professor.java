package app.entity;

import java.util.List;

import org.hibernate.validator.constraints.br.CPF;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Professor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long idProf;
	
	@Pattern (regexp = "\\S+\\s+\\S+.*$", message = "O nome deve conter duas palavras")
	private String nomeProf;
	
	@CPF(message = "O CPF deve ser válido")
	private String cpfProf;
	
	@Email (message = "O e-mail precisa ser válido")
	private String emailProf;
	
	@Pattern (regexp = "\\S+\\s+\\S+.*$", message = "O nome deve conter duas palavras")
	private String especialidadeProf;
	
	//Um(varios?) professor pode ter várias turmas.
	@ManyToMany
	@JoinTable(name = "professores_turma")
	private List <Turma> turmas;
	
}
