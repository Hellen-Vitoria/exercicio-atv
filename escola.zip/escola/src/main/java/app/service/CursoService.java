package app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.entity.Curso;
import app.repository.CursoRepository;

@Service
public class CursoService {
	
	@Autowired
	private CursoRepository cursoRepository;
	
	public String save (Curso curso) {
		this.cursoRepository.save(curso);
		return "Curso salvo com sucesso!";
		
	}
	
	public String update (Curso curso, long idCurso) {
		curso.setIdCurso(idCurso);
		this.cursoRepository.save(curso);
		return "Curso alterado com sucesso!";
		
	}
	
	public String delete (long idCurso) {	
		this.cursoRepository.deleteById(idCurso);
		return "Curso deletado com sucesso!";
	}
	
	public List<Curso> findAll (){
		List<Curso> lista = this.cursoRepository.findAll();
		return lista;
	}
	
	public Curso findById(long idCurso) {
		Curso curso = this.cursoRepository.findById(idCurso).get();
		return curso;
	}
}