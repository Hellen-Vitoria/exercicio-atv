package app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.entity.Aluno;
import app.repository.AlunoRepository;

@Service
public class AlunoService {
	
	@Autowired
	private AlunoRepository alunoRepository;
	
	public String save (Aluno aluno) {
		this.alunoRepository.save(aluno);
		return "Aluno salvo com sucesso!";
	}
	public String update (Aluno aluno, long idAluno) {
		aluno.setIdAluno(idAluno);
		this.alunoRepository.save(aluno);
		return "Aluno alterado com sucesso!";
	}
	public String delete (long idAluno) {
		this.alunoRepository.deleteById(idAluno);
		return "Aluno deletado com sucesso!";
	}
	public List<Aluno> findAll (){	
		List<Aluno> lista = this.alunoRepository.findAll();
		return lista;
	}
	public Aluno findById(long idAluno) {
		Aluno aluno = this.alunoRepository.findById(idAluno).get();
		return aluno;
	}
}