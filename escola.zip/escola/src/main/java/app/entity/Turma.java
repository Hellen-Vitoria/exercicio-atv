package app.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
//import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
//import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Turma {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long idTurma;
	
	@NotBlank (message = "O nome da Turma eh obrigatório")
	private String nomeTurma;
	
	private String semestreTurma;
	private String anoTurma;
	private String turnoTurma;
	
	//Uma turma pode existir sem alunos ou pode ter vários alunos
	//@OneToMany (mappedBy = "turma")
	//private List <Aluno> alunos;
	
	@ManyToOne
	@JoinColumn (name = "curso_id") //opcional
	@NotNull(message = "O curso é obrigatório para salvar uma turma")
	//@NotEmpty(message = "Não é possível existir uma turma sem pelo menos um curso associado")
	private Curso curso;
		
	//Uma(várias?) turma pode ter varios professores
	@ManyToMany (mappedBy = "turmas")
	private List<Professor> professores;
	//Uma turma deve obrigatoriamente estar associada a um unico curso
	
}
 