package app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.entity.Turma;
import app.repository.TurmaRepository;

@Service
public class TurmaService {
	
	@Autowired
	private TurmaRepository turmaRepository;
	
	public String save (Turma turma) {
		this.turmaRepository.save(turma);
		return "Turma salva com sucesso!";
	}
	public String update (Turma turma, long idTurma) {
		turma.setIdTurma(idTurma);
		this.turmaRepository.save(turma);
		return "Turma alterada com sucesso!";
	}
	public String delete (long idTurma) {
		this.turmaRepository.deleteById(idTurma);
		return "Turma deletada com sucesso!";
	}
	public List<Turma> findAll(){
		List<Turma> lista = this.turmaRepository.findAll();
		return lista;
	}
	public Turma findById(long idTurma) {
		Turma turma = this.turmaRepository.findById(idTurma).get();
		return turma;
	}
}